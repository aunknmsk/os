#include<stdio.h>
#include<pthread.h>

int a[10][10],b][10][10],res[10][10];
int r1,c1,r2,c2;

typedef struct p{
	int x;
	int y;
} *element;

void accept(int arr[10][10],int r,int c)
{
	printf("enter elements in the matrix\n");
	for (int i = 0; i < r; ++i)
	{
		for (int j = 0; j < c; ++j)
		{
			scanf("%d",&arr[i][j]);
		}
	}
}

void display(int arr[10][10],int r,int c)
{
	printf("elements are : \n");
	for (int i = 0; i < r; ++i)
	{
		printf("\n");
		for (int j = 0; j < c; ++j)
		{
			printf("%d ",arr[i][j]);
		}
	}

	printf("\n\n");
}

void * multi(void * param)
{
	int x,y,i,*j;
	element rc = (element)param;
	x = rc->x;
	y = rc->y;

	*j = (int *)malloc(sizeof(int *));

	for (int i = 0; i < r2 ; ++i)
	 {
			*j + = a[x][i] * b[i][y];	 	
	 } 

	 pthread_exit((void*)j);
}

int main()
{
	int i,j;
	pthread_t pid[10][10];
	void *s;

	printf("enter rowss and colomns in matrix 1 \n");
	scanf("%d%d",&r1,&c1);
	accept(a,r1,c1);
	display(a,r1,c1);

	printf("enter rows and colomns in matrix 2 \n");
	scanf("%d%d",&r2,&c2);
	accept(b,r2,c2);
	display(b,r2,c2);

	if (c1 == r2)
	{
		for (int i = 0; i < r1; ++i)
		{
			for (int j = 0; i < c2; ++j)
			{
				element rc = (element)malloc(sizeof(struct p));
				rc->x = i;
				rc->y = j;
				pthread_create(&pid[i][j],NULL,multi,(void*)rc);				
			}
		}

		for (int i = 0; i < r1; ++i)
		{
			for (int j = 0; i < c2; ++j)
			{
				pthread_join(pid[i][j],&s);
				res[i][j] = (*(int *s));			
			}
		}
	}

	return 0;
}