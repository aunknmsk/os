#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>

FILE *p;

int main()
{
	int fd1[2],fd2[2],j=0;
	char path[100],rd[100],content[100],c;
	
	strcpy(path,"/home/manas/test.txt");
	
	pipe(fd1);
	pipe(fd2);
	
	int pid = fork();
	
	if(pid == 0)
	{
	
		close(fd1[1]);
		read(fd1[0],path,sizeof(path));
		
		p = fopen(path,"r");
		/*c= fgetc(p);
		rd[j] = c;
		j++;*/
		while(c!= EOF)
		{
			c= fgetc(p);
		rd[j] = c;
		j++;
			
		}
		rd[--j]='\0';
		fclose(p);
		close(fd2[0]);
		write(fd2[1],rd,strlen(rd));		
	}
	
	else
	{
		close(fd1[0]);
		write(fd1[1],path,sizeof(path));
		sleep(2);          // remember if this sleep is less then output is not printed
		close(fd2[1]);
		read(fd2[0],content,sizeof(content));
		printf("\n%s",content);
	}
	
}
