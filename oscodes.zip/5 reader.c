#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<stdlib.h>

sem_t wrt,re;
pthread_t rd,wr;
int readcount = 0;

void * writer(void * param)
{
   int waitime;
   waitime = rand() % 5;
   printf("\n Writer is trying to enter");
   sem_wait(&wrt);
   printf("\n Writer is inside");
   sleep(waitime);
   sem_post(&wrt);
   printf("\n Writer is leaving");
   sleep(10);
}

void * reader(void * param)
{
   int waitime ;
   waitime = rand() % 3;
   printf("\n Reader trying to enter");
   
   sem_wait(&re);
   readcount++;
      if(readcount == 1)
      {
         sem_wait(&wrt);
      }
   sem_post(&re);
   
   printf("\n %d Reader is inside",readcount);
   sleep(20);
   
   sem_wait(&re);
   readcount--;
      if(readcount == 0)
      {
         sem_post(&wrt);
      }   
   sem_post(&re);
   
   printf("\n reader is leaving");
   sleep(10);   
}

int main()
{  int w,r;
   sem_init(&wrt,0,1);
   sem_init(&re,0,1);
   
   printf("\n Enter no of reader");
   scanf("%d",&r);
   printf("\n Enter no of writer");
   scanf("%d",&w);
 
   for(int j=0;j<r;j++)
   {
      pthread_create(&rd,NULL,reader,NULL);
   }
   
   for(int i=0;i<w;i++)
   {
      pthread_create(&wr,NULL,writer,NULL);
   }

   for(int i=0;i<r;i++)
   pthread_join(rd,NULL);
	
   for(int i=0;i<w;i++)
   pthread_join(wr,NULL);

   sleep(30);
   exit(0);
}
