#include<stdio.h>
#include <sys/types.h>          // for fork()
#include <unistd.h>                     // for fork()
#include<stdlib.h>         // for system()


void bbl_sort_ascending(int arr[10],int n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(arr[j] > arr[j+1])
			{
				temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
			}
		}
	}
}


void bbl_sort_descending(int arr[10],int n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(arr[j] < arr[j+1])
			{
				temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
			}
		}
	}
}

void display(int arr[10],int n)
{
	for(int i=0;i<n;i++)
	{
		printf("  %d",arr[i]);
	}
}



int main()
{
	int arr[10],size;
	
	printf("\nEnter the size of array :");
	scanf("%d",&size);
	
	printf("\nEnter the array elements:");
	for(int i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}
	
	
	
	int pid = fork();
	
	if(pid < 0)
		printf("\nError!!");
		
	else if( pid > 0)                         // parent process
	{
		//wait(10);
		printf("\nIn parent process.");
		bbl_sort_descending(arr,size);
		printf("\n Sorted in Descending Order :  ");
		display(arr,size);
		printf("\n\n.");
		printf("\n The child process id is : %d ", pid);
		system("ps");
		
		//system("ps");
		
		exit (0);
	}
	
	else if(pid == 0)               // child process
	{
		sleep(20);
		printf("\nIn child process");
		printf("\n Sorted in Ascending Order:");
		bbl_sort_ascending(arr,size);
		display(arr,size);
		
		
	//	exit(0);
	}
	
	
	
	return 0;
}
