#include<stdio.h>
#include<fcntl.h>
#include<string.h>
#include<ctype.h>
#include<sys/stat.h>
#include<unistd.h>

int main()
{
	int fd1,fd2,i=0,num;
	char c,input_buf[100],output_buf[100];
	mkfifo("f1",0644);
	fd1=open("f1",O_WRONLY);
	
	mkfifo("f2",0644);
	fd2=open("f2",O_RDONLY);
	
	printf("\nReady to send to client:");
		printf("\nEnter your message:\n");
	while((c=getc(stdin))!='`')
	input_buf[i++]=c;
	input_buf[i]='\0';
	
	write(fd1,input_buf,strlen(input_buf));
	
	while((num=read(fd2,output_buf,1000))>0)
	{
		output_buf[num]='\0';
		printf("\nStats recvveived from client!!:\n%s",output_buf);
		fflush(stdout);
		break;
	}
	
	return 0;
		
}
