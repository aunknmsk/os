#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>





int main(int argc,char *argv[])
{
	int i,j,r;
	char *temp;
	
	
	for(i=0;i<argc;i++)
	{
		printf("\n argv[%d] : %s",i,argv[i]);
	}
	
	for(i=0;i<argc-1;i++)
	{
		for(j=0;j<argc-i-1;j++)
		{
			if(atoi(argv[j]) > atoi(argv[j+1]))
			{
				temp = argv[j];
				argv[j] = argv[j+1];
				argv[j+1] = temp;
			}
		}
	}
	
	printf("\nAscending order is : ");
	
	for(i=1;i<argc;i++)
	{
		printf("\n %d ",atoi(argv[i]));
		
		printf("\n now going in other code");
	}
	
	
	int pid = fork();
	
	if(pid<0)
	{
		printf("Error!!");
	}
	
	else if(pid == 0)
	{
		execve("./bin",argv,NULL);
		printf("not gone to 2nd Program");
		exit(200);
		
	}
	
	else if(pid > 0)
	{
		int cpid;
		cpid=wait(&r);
		printf("\nno program to execute in parent");
	}
	return 0;
}





