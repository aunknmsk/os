#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>

#define SRC "student.txt"
#define DEST "temp.txt"

typedef struct Employee
{
	char name[30];
	int eid;
	char address[30];
}emp;


void insert()
{
	int in,out;
	emp e;
	in = open(SRC,O_WRONLY|O_APPEND|O_CREAT,0666);
	 if(in == -1)
	 {
	 	printf("\nError in opening the file");
	 	exit(0);
	 }
	 
	 else
	 {
	 	printf("\nEnter employee name:");
	 	scanf("%s",e.name);
	 	printf("\nEnter employee id:");
	 	scanf("%d",&e.eid);
	 	printf("\nEnter employee address:");
	 	scanf("%s",e.address);
	 	write(in,&e,sizeof(emp));
	 	close(in);
	 }
}

void display()
{
	emp e;
	int in,out;
	in = open(SRC,O_RDONLY,0666);
	if(in == -1)
	{
		printf("\nError in opening the file");
	 	exit(0);
	}
	else
	{
		while(read(in,&e,sizeof(emp)))
		{	
			printf("\n%s   %d    %s",e.name,e.eid,e.address);
		}
	}
	close(in);
}


void search()
{
	int key,in,flag =0;
	emp e;
	printf("\nEnter id to be searched:");
	scanf("%d",&key);
	in = open(SRC,O_RDONLY,0666);
	
	if(in == -1)
	{
		printf("\nError in opening file");
		exit(0);
	}
	
	else
	{
		while(read(in,&e,sizeof(emp)))
		{
			if(e.eid == key)
			{
				printf("\nEmployee name is :%s",e.name);
				printf("\nEmployee id is :%d",e.eid);
				printf("\nEmployee address is :%s",e.address);
				flag = 1;
				//break;
			}	
		}	
	}
	
	if(flag == 0)
	{
		printf("\nnot found");
	}
	
	close(in);
}



void modify()
{
	int key,flag=0,in1,in2;
	emp e;
	printf("\nEnter the id to be modified:");
	scanf("%d",&key);
	
	in1 = open(SRC,O_RDONLY,0666);
	in2 = open(DEST,O_WRONLY|O_APPEND|O_CREAT,0666);
	
	if(in1 == -1 || in2 == -1)
	{
		printf("\nError in opening one of the files!!");
	}
	
	else
	{
		while(read(in1,&e,sizeof(emp)))
		{
			if(key == e.eid)
			{printf("\nEmployee new name is :%s",e.name);
			scanf("%s",e.name);
			printf("\nEmployee new id is :%d",e.eid);
			scanf("%d",&e.eid);
			printf("\nEmployee new address is :%s",e.name);
			scanf("%s",e.address);
			flag = 1;
			}
			
			write(in2,&e,sizeof(emp));
		}
		
		if(flag == 0)
		{
			printf("\nrecord you want to modify not found");
		}
		
		else
		{
			remove(SRC);
			rename(DEST,SRC);
	 		/*in1=open(SRC,O_RDONLY,0666);
		printf("\nSource file opened");
		printf("\nEMP_ID\tNAME");
		while(read(in1,&e,sizeof(emp)))
			printf("\n%s  %d   %s",e.name,e.eid,e.address);
		close(in1);*/
		}
		
		
	}
	
	close(in1);
	close(in2);
	
	
}


void delete()
{
	int key,flag=0,in1,in2;
	emp e;
	printf("\nEnter the id to be modified:");
	scanf("%d",&key);
	
	in1 = open(SRC,O_RDONLY,0666);
	in2 = open(DEST,O_WRONLY|O_APPEND|O_CREAT,0666);
	
	if(in1 == -1 || in2 == -1)
	{
		printf("\nError in opening one of the files!!");
	}
	
	else
	{
		while(read(in1,&e,sizeof(emp)))
		{
			if(key == e.eid)
			flag =1;
			
			else
			write(in2,&e,sizeof(emp));
		}
		
		if(flag == 0)
		{
			printf("\nrecord you want to modify not found");
		}
		
		else
		{
			remove(SRC);
			rename(DEST,SRC);
	 		/*in1=open(SRC,O_RDONLY,0666);
		printf("\nSource file opened");
		printf("\nEMP_ID\tNAME");
		while(read(in1,&e,sizeof(emp)))
			printf("\n%s  %d   %s",e.name,e.eid,e.address);
		close(in1);*/
		}
		
		
	}
	
	close(in1);
	close(in2);
	
	
}


int main()
{
	int ch;
	
	do
	{
		printf("\n\nMENU\n1.Insert\n2.Display\n3.Search\n4.Modify\n5.Delete\n7.Exit\n\nEnter your choice :");
		scanf("%d",&ch);
		
		switch(ch)
		{
			case 1 :insert();
				break;
				
			case 2 :display();
				break;
				
			case 3 :search();
				break;
				
			case 4 :modify();
				break;
				
			case 5 :delete();
				break;
				
				
			case 7 :printf("\nGOODBYE!!");
				break;
				
			default:printf("\nEnter valid choice!!");
				break;
		}
		
	}while(ch!=7);
	return 0;
}
