#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<stdlib.h>

pthread_mutex_t mutex;
sem_t full,empty;
int counter;
int buffer[10];

void init()
{
   pthread_mutex_init(&mutex , NULL);
   sem_init(&full, 0, 0);
   sem_init(&empty, 0, 10);
   counter = 0;
}

int produce_item(int item)
{
	if(counter<10)
	{
		buffer[counter]=item;
		counter++;
		return 1;
	}

	else
	{
		return 0;
	}
}

int consume_item(int *item)
{
	if(counter>0)
	{
		*item = buffer[counter-1];
		counter--;
		return 1;
	}

	else
		return 0;
}
 
void *producer(void *param)
{
    int item;
    while(1)
    {
    	int stime,item;
    	stime = rand()/100000000;
    	sleep(stime);
    	item = rand();
    	sem_wait(&empty);
    	pthread_mutex_lock(&mutex);

    	if(produce_item(item) == 1)
    	{
 			printf("\nItem produced is %d", item);
    	} 

    	else
    	{
    		printf("buffer filled");
    	}

    	sem_post(&empty);
    	pthread_mutex_unlock(&mutex);
    }
}

void *consumer(void *param)
{
    int item;
    while(1)
    {
    	int stime,item;
    	stime = rand()/100000000;
    	sleep(stime);
    	item = rand();
    	sem_wait(&full);
    	pthread_mutex_lock(&mutex);

    	if(consume_item(item) == 1)
    	{
 			printf("\nItem produced is %d", item);
    	} 

    	else
    	{
    		printf("\nBuffer empty!!");
    	}

    	sem_post(&full);
    	pthread_mutex_unlock(&mutex);
    }
}
int main()
{
	int numpro,numcon,i;
	pthread_t pro,con;
	init();

	printf("\nenter no. of producer");
	scanf("%d",numpro);

	printf("\nenter no. of consumer");
	scanf("%d",numcon);

	for(i=0;i<numpro;i++)
	{
		pthread_create(&pro,NULL,producer,NULL);
	}

	for (int i = 0; i < numcon; ++i)
	{
		pthread_create(%con,NULL,consumer,NULL);
	}

	sleep(20);

	printf("\nExiting!!");
	exit(0);

}