#include<stdio.h>
#include<fcntl.h>
#include<string.h>
#include<ctype.h>
#include<sys/stat.h>
#include<unistd.h>
int main()
{
	int i,fd1,fd2,num,no_of_chars=0,no_of_words=0,no_of_lines=0;
	FILE *fp = fopen("statistics.txt","w+");
	char input_buf[100],output_buf[100],a[100];
	
	
	mkfifo("f1",0644);
	fd1=open("f1",O_RDONLY);
	
	mkfifo("f2",0644);
	fd2=open("f2",O_WRONLY);
	
	printf("\nready to receive from server side\n");
	while((num=read(fd1,input_buf,1000))>0)
	{
		input_buf[num] = '\0';
		printf("\nReceived from server usinf fifo2\n%s:",input_buf);
		fflush(stdout);
		break;
	}
	
	for(i=0;i<strlen(input_buf);i++)
	{
		if(isalnum(input_buf[i]))
		no_of_chars++;
		
		else if(isspace(input_buf[i]))
		no_of_words++;
		
		if(input_buf[i] == '\n')
		no_of_lines++;
	}
	
	if(!isspace(input_buf[strlen(input_buf)]))
 no_of_words++;
 
	
	fprintf(fp,"\nno of chars:%d",no_of_chars);
	fprintf(fp,"\nno of words:%d",no_of_words);
	fprintf(fp,"\nno of lines:%d",no_of_lines+1);
	printf("\n Sending stats to server using fifo2");
	rewind(fp);
	
	for(i=0;fgets(a,sizeof(a),fp)!=NULL;i++)
	strcat(output_buf,a);
	
	
	write(fd2,output_buf,strlen(output_buf));
	write(fd1,"\n",1);
	fclose(fp);
	return 0; 
	
	
}
