#!/bin/sh opt=1
while [ $opt -ne 7 ] 
do
echo
echo "------------------ "
echo "Student Database" 
echo "-------------------"
echo
echo "1.Create the database" 
echo "2.Insert a record" 
echo "3.Search a record" 
echo "4.Modify a record" 
echo "5.Delete a record" 
echo "6.Display"
echo "7.Exit"

read opt 
case $opt in 

1)
echo
echo "-------------------"
echo "| CREATE DATABASE |" 
echo "-------------------"
echo
echo "How many records you want to insert?" 
read n
count=0
while [ $count -ne $n ] 
do
echo "Please enter Student Information"
echo "Enter the roll number"
read roll
echo "Enter the Name"
read name
echo "Enter branch" 
read branch
record="$roll $name $branch"
`echo $record | cat >> db.txt`
count=$(($count+1))
done
echo "Record inserted successfully!"
;;

2)
echo
echo "----------"
echo "| INSERT |" 
echo "----------"
echo
echo "Please enter Student Information" echo "Enter the roll number"
read roll
echo "Enter the Name" 
read name
echo "Enter branch" 
read branch
record="$roll $name $branch"
`echo $record | cat >> db.txt`

;; 

3)
echo
echo "----------"
echo "| SEARCH |" 
echo "----------"
echo
echo "Enter name/roll_no to search" read key
if grep -q $key db.txt; then
echo "Record found successfully" 
grep -n $key db.txt
else
echo "Record not found :(" 
fi

;; 

4)
echo
echo "----------"
echo "| MODIFY |"
echo "----------"
echo
echo "enter roll no. to be modified" 
read n

var=`grep -n ^$n db.txt | cut -c 1` 
var1=` expr $var - 1 `
head -$var1 db.txt | cat > temp

echo "Enter new Information" 
echo "Enter the roll number" 
read roll
echo "Enter the Name" 
read name
echo "Enter branch" 
read branch
record="$roll $name $branch" 
echo $record | cat >> db.txt 
var2=` wc -l < db.txt `
var3=` expr $var2 - $var `
tail -$var3 db.txt | cat >> temp 
mv temp db.txt
;;

5)
echo
echo "----------"
echo "| DELETE |" 
echo "----------"
echo
echo "Enter Roll number to be deleted" 
read n
if grep -q $n db.txt; then
echo "Record deleted successfully" 
else
echo "Record not found :(" 
fi

grep -v ^$n db.txt | cat > temp 
mv temp db.txt
;;

6)
echo
echo "-----------"
echo "| DISPLAY |" 
echo "-----------"
echo
echo "----------------------------"
echo "Name Roll No. Branch "
cat db.txt
echo "----------------------------"
echo
;;

7)
echo "GoodBye!"
;;

*)
echo "Please select valid option"
;;
esac done

